from django.contrib import admin
from .models import ParkingSlot, Booking

admin.site.register(ParkingSlot)
admin.site.register(Booking)
